parent(john,mary). parent(john,peter).
parent(susan,mary). parent(susan,peter).
parent(peter,alice). parent(anna,alice).
father(X,Y):-parent(X,Y),male(X).
mother(X,Y):-parent(X,Y),female(X).
male(john). male(peter). female(susan). female(anna).
% Query: ?- parent(john,mary).
