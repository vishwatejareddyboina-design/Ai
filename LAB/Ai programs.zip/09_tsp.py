from itertools import permutations
n=int(input("Number of cities: "))
a=[list(map(int,input().split())) for _ in range(n)]
best=(10**9,None)
for p in permutations(range(1,n)):
    route=(0,)+p+(0,)
    cost=sum(a[route[i]][route[i+1]] for i in range(n))
    if cost<best[0]: best=(cost,route)
print("Minimum cost:",best[0],"Route:",best[1])
