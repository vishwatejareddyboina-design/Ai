import random
states=["Sunny","Rainy"]
P={"Sunny":{"Sunny":.8,"Rainy":.2},"Rainy":{"Sunny":.4,"Rainy":.6}}
s=input("Start state (Sunny/Rainy): ")
for _ in range(10):
    print(s,end=" ")
    s=random.choices(states,[P[s][x] for x in states])[0]
