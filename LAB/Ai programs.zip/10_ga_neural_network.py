import random
from sklearn.neural_network import MLPClassifier
X=[[0,0],[0,1],[1,0],[1,1]]; y=[0,1,1,0]
# Genetic algorithm evolves hidden-layer size; fitness = XOR accuracy.
sizes=[random.randint(2,10) for _ in range(10)]
for _ in range(10):
    scored=[]
    for s in sizes:
        m=MLPClassifier(hidden_layer_sizes=(s,),max_iter=3000,random_state=1).fit(X,y)
        scored.append((m.score(X,y),s))
    scored.sort(reverse=True)
    parents=[s for _,s in scored[:3]]
    sizes=parents[:]
    while len(sizes)<10:
        sizes.append(max(2,min(10,random.choice(parents)+random.randint(-2,2))))
best=max(scored)
print("Best hidden neurons:",best[1],"Accuracy:",best[0])
