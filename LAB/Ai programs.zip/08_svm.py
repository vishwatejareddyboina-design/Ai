from sklearn.svm import SVC
X=[[1,1],[2,1],[1,2],[8,8],[9,8],[8,9]]
y=[0,0,0,1,1,1]
m=SVC(kernel="linear").fit(X,y)
x=list(map(float,input("Two features: ").split()))
print("Class:",m.predict([x])[0])
