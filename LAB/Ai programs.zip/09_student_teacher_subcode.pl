teaches(rajesh,ai,cs101).
teaches(priya,dbms,cs102).
student(anu,cs101).
student(kavi,cs102).
% Query: ?- student(Student,Code), teaches(Teacher,Subject,Code).
