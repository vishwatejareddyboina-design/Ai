import random
def fitness(x): return -(x-5)**2+25
pop=[random.uniform(0,10) for _ in range(20)]
for _ in range(100):
    pop=sorted(pop,key=fitness,reverse=True)[:10]
    children=pop[:]
    while len(children)<20:
        p=random.choice(pop); c=min(10,max(0,p+random.uniform(-1,1)))
        children.append(c)
    pop=children
best=max(pop,key=fitness)
print("Best x:",best,"Fitness:",fitness(best))
