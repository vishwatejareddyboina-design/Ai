import numpy as np, random
# Q-learning on a 1D world: state 0 -> goal 4
Q=np.zeros((5,2)); alpha=.5; gamma=.9
for _ in range(1000):
    s=0
    while s!=4:
        a=random.randrange(2) if random.random()<.1 else np.argmax(Q[s])
        ns=max(0,s-1) if a==0 else min(4,s+1)
        r=10 if ns==4 else -1
        Q[s,a]+=alpha*(r+gamma*np.max(Q[ns])-Q[s,a])
        s=ns
print("Q-table:\n",Q)
