def minimax(depth,maximizing,values):
    if depth==3: return values.pop(0)
    vals=[minimax(depth+1,not maximizing,values) for _ in range(2)]
    return max(vals) if maximizing else min(vals)
values=list(map(int,input("8 leaf values: ").split()))
print("Best value:",minimax(0,True,values))
