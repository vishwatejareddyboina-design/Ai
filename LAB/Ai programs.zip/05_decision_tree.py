from sklearn.tree import DecisionTreeClassifier
X=[[0,0],[0,1],[1,0],[1,1],[2,0],[2,1]]
y=[0,1,1,1,0,0]
m=DecisionTreeClassifier(random_state=0).fit(X,y)
a=list(map(float,input("Two features: ").split()))
print("Predicted class:",m.predict([a])[0])
