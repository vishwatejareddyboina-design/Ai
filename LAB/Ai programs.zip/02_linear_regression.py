from sklearn.linear_model import LinearRegression
X=[[1],[2],[3],[4],[5]]; y=[2,4,5,8,10]
m=LinearRegression().fit(X,y)
x=float(input("X: "))
print("Predicted Y:",m.predict([[x]])[0])
