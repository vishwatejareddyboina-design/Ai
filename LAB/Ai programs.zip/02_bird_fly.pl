bird(sparrow). bird(eagle). bird(penguin). bird(ostrich).
can_fly(sparrow). can_fly(eagle).
cannot_fly(X) :- bird(X), \+ can_fly(X).
% Queries: ?- can_fly(eagle).  ?- cannot_fly(penguin).
