from sklearn.datasets import load_iris
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
X,y=load_iris(return_X_y=True)
grid=GridSearchCV(SVC(),{"C":[.1,1,10],"kernel":["linear","rbf"]},cv=5)
grid.fit(X,y)
print("Best parameters:",grid.best_params_)
print("Best score:",grid.best_score_)
