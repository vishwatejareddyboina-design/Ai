edge(a,b,4). edge(a,c,2). edge(b,d,5). edge(c,d,1). edge(d,e,3).
best_first(Start,Goal,Path):- search([Start],Goal,[],Path).
search([Goal|_],Goal,_,[Goal]).
search([Node|Rest],Goal,Seen,Path):-
    findall(H-N,(edge(Node,N,H),\+member(N,[Node|Seen])),Pairs),
    keysort(Pairs,Sorted), pairs_nodes(Sorted,Nodes),
    append(Nodes,Rest,Queue), search(Queue,Goal,[Node|Seen],P),
    P=[N|_], Path=[Node|P].
pairs_nodes([],[]).
pairs_nodes([_-N|T],[N|R]):-pairs_nodes(T,R).
% Query: ?- best_first(a,e,P).
