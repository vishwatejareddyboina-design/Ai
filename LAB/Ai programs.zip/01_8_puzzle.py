from heapq import heappush, heappop

def h(s, goal):
    return sum(abs(i//3-(goal.index(x))//3)+abs(i%3-goal.index(x)%3)
               for i,x in enumerate(s) if x != 0)

def solve(start, goal=(1,2,3,4,5,6,7,8,0)):
    pq=[(h(start,goal),0,start,[])]
    seen=set()
    while pq:
        _,g,s,path=heappop(pq)
        if s==goal: return path+[s]
        if s in seen: continue
        seen.add(s)
        z=s.index(0); r,c=divmod(z,3)
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            nr,nc=r+dr,c+dc
            if 0<=nr<3 and 0<=nc<3:
                ns=list(s); j=nr*3+nc
                ns[z],ns[j]=ns[j],ns[z]; ns=tuple(ns)
                if ns not in seen:
                    heappush(pq,(g+1+h(ns,goal),g+1,ns,path+[s]))
start=tuple(map(int,input("Enter 9 values (0=blank): ").split()))
ans=solve(start)
if ans:
    for s in ans: print(s[:3],s[3:6],s[6:])
else: print("No solution")
