from heapq import heappush,heappop
g={}
for _ in range(int(input("Edges: "))):
    u,v,w=input().split(); w=int(w); g.setdefault(u,[]).append((v,w))
h={x:int(y) for x,y in (input("Heuristic node value pairs: ").split() for _ in range(int(input("Heuristic count: "))))}
start,goal=input("Start Goal: ").split()
pq=[(h[start],0,start,[start])]; best={}
while pq:
    f,d,u,path=heappop(pq)
    if u==goal: print("Path:",path,"Cost:",d); break
    if u in best and best[u]<=d: continue
    best[u]=d
    for v,w in g.get(u,[]): heappush(pq,(d+w+h.get(v,0),d+w,v,path+[v]))
else: print("No path")
