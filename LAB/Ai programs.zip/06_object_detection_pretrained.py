# Requires: pip install opencv-python
# Uses OpenCV's pretrained MobileNet-SSD files.
import cv2
net=cv2.dnn.readNetFromCaffe("deploy.prototxt","mobilenet_iter_73000.caffemodel")
img=cv2.imread("input.jpg")
blob=cv2.dnn.blobFromImage(cv2.resize(img,(300,300)),.007843,(300,300),127.5)
net.setInput(blob); detections=net.forward()
print("Detections:",detections.shape[2])
for i in range(detections.shape[2]):
    conf=detections[0,0,i,2]
    if conf>.5: print("Class ID:",int(detections[0,0,i,1]),"Confidence:",float(conf))
