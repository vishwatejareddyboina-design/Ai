from collections import deque
g={}
for _ in range(int(input("Edges: "))):
    u,v=input().split(); g.setdefault(u,[]).append(v); g.setdefault(v,[]).append(u)
start=input("Start: "); q=deque([start]); seen={start}
while q:
    u=q.popleft(); print(u,end=" ")
    for v in g.get(u,[]):
        if v not in seen: seen.add(v); q.append(v)
