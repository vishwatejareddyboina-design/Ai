person(anu,'10-05-2005').
person(raju,'21-11-2004').
person(kavi,'03-01-2006').
% Query: ?- person(Name,DOB).
