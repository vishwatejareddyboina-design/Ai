from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
texts=["I love this product","This is excellent","I hate this","Very bad product"]
y=[1,1,0,0]
v=TfidfVectorizer(); X=v.fit_transform(texts)
m=LogisticRegression().fit(X,y)
s=input("Review: ")
print("Positive" if m.predict(v.transform([s]))[0] else "Negative")
