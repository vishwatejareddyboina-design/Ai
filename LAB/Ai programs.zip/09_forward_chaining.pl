fact(sunny).
rule(sunny,warm).
rule(warm,go_out).
forward(Facts,Goal):- member(Goal,Facts), !.
forward(Facts,Goal):- rule(A,B),member(A,Facts),\+member(B,Facts),
    forward([B|Facts],Goal).
% Query: ?- forward([sunny],go_out).
