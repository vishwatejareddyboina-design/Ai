from sklearn.cluster import KMeans
X=[[1,1],[1,2],[2,1],[8,8],[9,8],[8,9]]
m=KMeans(n_clusters=2,n_init=10,random_state=0).fit(X)
print("Labels:",m.labels_)
print("Centers:",m.cluster_centers_)
