def solve(n):
    board=[-1]*n
    def backtrack(r):
        if r==n:
            print(*board); return True
        for c in range(n):
            if all(board[i]!=c and abs(board[i]-c)!=abs(i-r) for i in range(r)):
                board[r]=c
                if backtrack(r+1): return True
                board[r]=-1
        return False
    return backtrack(0)

n=int(input("N: "))
print("Column positions:", end=" ")
print("Solution exists" if solve(n) else "No solution")
