disease(diabetes). disease(hypertension). disease(anemia).
diet(diabetes,'low sugar, high fiber').
diet(hypertension,'low salt, fruits and vegetables').
diet(anemia,'iron rich foods, green leafy vegetables').
suggest(D,Diet):-diet(D,Diet).
% Query: ?- suggest(diabetes,Diet).
