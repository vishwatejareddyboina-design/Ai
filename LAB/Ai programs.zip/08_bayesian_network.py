# Requires: pip install pgmpy
from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination
m=DiscreteBayesianNetwork([("Rain","WetGrass")])
cpd1=TabularCPD("Rain",2,[[.7],[.3]])
cpd2=TabularCPD("WetGrass",2,[[.9,.2],[.1,.8]],evidence=["Rain"],evidence_card=[2])
m.add_cpds(cpd1,cpd2); m.check_model()
print(VariableElimination(m).query(["WetGrass"]))
