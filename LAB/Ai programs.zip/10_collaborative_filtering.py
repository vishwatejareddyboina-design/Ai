import numpy as np
R=np.array([[5,4,0,0],[4,5,1,0],[0,1,5,4],[0,0,4,5]],dtype=float)
# User-user cosine similarity
S=R@R.T/(np.linalg.norm(R,axis=1)[:,None]*np.linalg.norm(R,axis=1)[None,:]+1e-9)
u=int(input("User index 0-3: "))
scores=S[u]@R/(S[u].sum()+1e-9)
scores[R[u]>0]=-1
print("Recommended item:",np.argmax(scores))
