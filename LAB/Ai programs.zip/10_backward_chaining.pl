fact(sunny).
rule(sunny,warm).
rule(warm,go_out).
prove(X):-fact(X).
prove(X):-rule(A,X),prove(A).
% Query: ?- prove(go_out).
