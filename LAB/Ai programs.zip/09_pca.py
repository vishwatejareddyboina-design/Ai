from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
X=[[2,8,10],[3,9,11],[4,10,12],[20,30,40]]
Z=StandardScaler().fit_transform(X)
Y=PCA(n_components=2).fit_transform(Z)
print(Y)
