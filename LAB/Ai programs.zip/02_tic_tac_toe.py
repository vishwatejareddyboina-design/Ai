b=[" "]*9
def show(): print("\n".join(["|".join(b[i:i+3]) for i in (0,3,6)]))
for turn in range(9):
    show(); p="X" if turn%2==0 else "O"
    i=int(input(f"{p} position 1-9: "))-1
    if b[i]!=" ": print("Invalid"); continue
    b[i]=p
    if any(all(b[i]==p for i in line) for line in ((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6))):
        show(); print(p,"wins"); break
else: show(); print("Draw")
