from sklearn.neighbors import KNeighborsClassifier
X=[[1,1],[1,2],[2,1],[8,8],[9,8],[8,9]]
y=["A","A","A","B","B","B"]
m=KNeighborsClassifier(n_neighbors=3).fit(X,y)
x=list(map(float,input("Two features: ").split()))
print("Class:",m.predict([x])[0])
