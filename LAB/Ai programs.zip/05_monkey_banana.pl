move(state(middle,onfloor,middle,hasnot),state(middle,onbox,middle,hasnot),'Monkey climbs box').
move(state(P,onfloor,P,hasnot),state(middle,onfloor,middle,hasnot),'Monkey pushes box').
move(state(P,onfloor,B,hasnot),state(P,onfloor,B,hasnot),'Monkey walks').
move(state(middle,onbox,middle,hasnot),state(middle,onbox,middle,has),'Monkey gets banana').
goal(state(_,_,_,has)).
