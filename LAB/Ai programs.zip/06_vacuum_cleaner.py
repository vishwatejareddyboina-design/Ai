def vacuum(world, pos):
    for _ in range(4):
        print("State:",world,"Position:",pos)
        if world[pos]=="Dirty":
            world[pos]="Clean"; print("Action: Suck")
        else:
            pos=1-pos; print("Action: Move")
    print("Final:",world)
world=input("Left/Right status (Dirty/Clean): ").split()
vacuum(world,0)
