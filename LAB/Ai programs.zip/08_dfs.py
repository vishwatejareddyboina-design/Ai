g={}
for _ in range(int(input("Edges: "))):
    u,v=input().split(); g.setdefault(u,[]).append(v); g.setdefault(v,[]).append(u)
seen=set()
def dfs(u):
    seen.add(u); print(u,end=" ")
    for v in g.get(u,[]):
        if v not in seen: dfs(v)
dfs(input("Start: "))
