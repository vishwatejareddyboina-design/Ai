symptom(fever,cold). symptom(cough,cold).
symptom(fever,flu). symptom(body_pain,flu).
symptom(chest_pain,heart_disease).
diagnose(D,S):-symptom(S,D).
% Query: ?- diagnose(D,fever).
