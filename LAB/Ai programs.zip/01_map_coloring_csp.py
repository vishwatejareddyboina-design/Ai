colors=["Red","Green","Blue"]
g={"A":["B","C"],"B":["A","C","D"],"C":["A","B","D"],"D":["B","C"]}
assign={}
def solve():
    if len(assign)==len(g): return True
    v=next(x for x in g if x not in assign)
    for c in colors:
        if all(assign.get(n)!=c for n in g[v]):
            assign[v]=c
            if solve(): return True
            del assign[v]
    return False
solve(); print(assign)
