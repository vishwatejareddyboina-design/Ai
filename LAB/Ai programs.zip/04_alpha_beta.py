def ab(depth,node,maximizing,alpha,beta,tree):
    if depth==3: return tree[node]
    if maximizing:
        v=-10**9
        for ch in (2*node+1,2*node+2):
            v=max(v,ab(depth+1,ch,False,alpha,beta,tree)); alpha=max(alpha,v)
            if alpha>=beta: break
        return v
    v=10**9
    for ch in (2*node+1,2*node+2):
        v=min(v,ab(depth+1,ch,True,alpha,beta,tree)); beta=min(beta,v)
        if alpha>=beta: break
    return v
tree=list(map(int,input("8 leaf values: ").split()))
print("Optimal value:",ab(0,0,True,-10**9,10**9,tree))
