fruit(apple,red). fruit(banana,yellow). fruit(grape,green).
fruit(orange,orange). fruit(watermelon,green).
% Query: ?- fruit(F,C). Press ; for backtracking.
