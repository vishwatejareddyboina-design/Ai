from collections import deque
# state=(missionaries_left,cannibals_left,boat_side), 1=left, 0=right
def safe(m,c): return 0<=m<=3 and 0<=c<=3 and (m==0 or m>=c) and (3-m==0 or 3-m>=3-c)
q=deque([((3,3,1),[])])
seen={(3,3,1)}
moves=[(1,0),(2,0),(0,1),(0,2),(1,1)]
while q:
    s,path=q.popleft()
    if s==(0,0,0):
        print(*[x for x in path+[s]],sep="\n"); break
    m,c,b=s
    for dm,dc in moves:
        ns=(m-dm,c-dc,0) if b else (m+dm,c+dc,1)
        if safe(ns[0],ns[1]) and ns not in seen:
            seen.add(ns); q.append((ns,path+[s]))
