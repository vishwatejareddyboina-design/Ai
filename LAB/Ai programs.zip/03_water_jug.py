from collections import deque
A,B,target=map(int,input("Capacities A B and target: ").split())
q=deque([((0,0),[])])
seen={(0,0)}
while q:
    (a,b),path=q.popleft()
    if a==target or b==target:
        for x in path+[(a,b)]: print(x)
        break
    nxt=[(A,b),(a,B),(0,b),(a,0),
         (max(0,a-(B-b)),min(B,b+a)),
         (min(A,a+b),max(0,b-(A-a)))]
    for s in nxt:
        if s not in seen:
            seen.add(s); q.append((s,path+[(a,b)]))
else: print("No solution")
