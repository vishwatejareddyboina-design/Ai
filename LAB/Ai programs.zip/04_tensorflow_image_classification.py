import tensorflow as tf
from tensorflow.keras import layers,models
(xtr,ytr),(xte,yte)=tf.keras.datasets.mnist.load_data()
xtr=xtr[...,None]/255.0; xte=xte[...,None]/255.0
m=models.Sequential([layers.Conv2D(16,3,activation='relu',input_shape=(28,28,1)),
 layers.MaxPooling2D(),layers.Flatten(),layers.Dense(64,activation='relu'),
 layers.Dense(10,activation='softmax')])
m.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy'])
m.fit(xtr,ytr,epochs=2,validation_split=.1)
print("Test accuracy:",m.evaluate(xte,yte,verbose=0)[1])
