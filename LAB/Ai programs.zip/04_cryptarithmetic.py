from itertools import permutations

def solve():
    words=["SEND","MORE"]; result="MONEY"
    letters=sorted(set("".join(words)+result))
    for p in permutations(range(10),len(letters)):
        d=dict(zip(letters,p))
        if d["S"]==0 or d["M"]==0: continue
        def val(w): return sum(d[c]*10**i for i,c in enumerate(w[::-1]))
        if val(words[0])+val(words[1])==val(result):
            print(d, val(words[0]),"+",val(words[1]),"=",val(result)); return
    print("No solution")
solve()
