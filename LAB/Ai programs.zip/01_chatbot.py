import re
responses={"hello":"Hello!","hi":"Hi!","bye":"Goodbye!","name":"I am an AI chatbot."}
while True:
    s=input("You: ").lower()
    if s in ("bye","exit","quit"): print("Bot:",responses["bye"]); break
    key=next((k for k in responses if re.search(k,s)),None)
    print("Bot:",responses.get(key,"Sorry, I don't understand."))
