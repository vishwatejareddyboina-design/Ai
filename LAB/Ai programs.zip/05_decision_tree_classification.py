from sklearn.tree import DecisionTreeClassifier
X=[[1,2],[2,3],[3,3],[8,7],[9,8],[8,9]]
y=[0,0,0,1,1,1]
m=DecisionTreeClassifier(random_state=0).fit(X,y)
x=list(map(float,input("Two features: ").split()))
print("Class:",m.predict([x])[0])
