from sklearn.neural_network import MLPClassifier
X=[[0,0],[0,1],[1,0],[1,1]]; y=[0,1,1,0]
m=MLPClassifier(hidden_layer_sizes=(4,),activation="tanh",max_iter=5000,random_state=1)
m.fit(X,y)
for x in X: print(x,"->",m.predict([x])[0])
