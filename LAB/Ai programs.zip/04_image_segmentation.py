import cv2
import numpy as np
img=cv2.imread("input.jpg",0)
if img is None: raise FileNotFoundError("Place input.jpg in this folder.")
_,seg=cv2.threshold(img,127,255,cv2.THRESH_BINARY)
cv2.imwrite("segmented.jpg",seg)
print("Saved segmented.jpg")
